# JARVIS — Android AI Assistant

An original, futuristic personal AI assistant for Android, built with Kotlin, Jetpack Compose,
and Clean Architecture (MVVM + Repository + Hilt). Inspired by the *idea* of a personal AI
assistant — no Marvel branding, voices, or artwork are used anywhere in this project.

## ⚠️ One-time setup step before building

This repository ships without the `gradle-wrapper.jar` binary (binary files aren't generated
by the assistant that authored this scaffold). Before building, do **one** of the following:

- **Easiest:** open the project in Android Studio (Giraffe or newer). It will detect the
  missing wrapper jar and offer to regenerate it automatically on first sync.
- **CLI:** if you have any local Gradle install, run `gradle wrapper --gradle-version 8.7`
  from the project root to generate `gradle/wrapper/gradle-wrapper.jar`.

Everything else (`gradlew`, `gradlew.bat`, `gradle-wrapper.properties`, all source, all Gradle
config) is already in place.

## Features

- Animated, glassmorphism "AI core" home dashboard with live battery / network / storage / RAM status
- Wake word ("Jarvis") detection via a battery-conscious foreground service
- Speech-to-text and emotion-aware text-to-speech (calm, polite, serious, excited, reassuring…)
- Kazakh, Russian, and English support with automatic language detection
- OpenAI-compatible chat completions API integration with persisted conversation memory (Room)
- Dynamic app launcher — resolves spoken app names against installed apps via `PackageManager`
  at runtime (no hardcoded package list)
- Natural-language reminders ("tomorrow morning", "in two hours", "next Friday") scheduled with
  WorkManager
- Notification listener and Accessibility Service, both strictly opt-in and gated on
  explicit user-granted permissions
- Local, persistent memory (Room) with a settings screen for language, API key, offline mode,
  and feature toggles (DataStore-backed)

## Architecture

Clean Architecture, MVVM, Hilt DI:

```
ui/            Compose screens, components, and theme (presentation layer)
domain/        Framework-agnostic models
data/          Room database, DataStore settings, repositories, remote API (data layer)
service/       Foreground service, notification listener, accessibility service, WorkManager worker
voice/         Speech-to-text and text-to-speech wrappers
ai/            Natural-language command parsing
util/          App launcher, system status, natural-language time parsing, reminder scheduler
di/            Hilt modules
```

## Build

```bash
./gradlew assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/`.

## API key configuration

Copy `local.properties.example` to `local.properties` and fill in your OpenAI-compatible
endpoint and key:

```properties
JARVIS_API_BASE_URL=https://api.openai.com/v1/
JARVIS_API_KEY=sk-...
```

`local.properties` is gitignored. The key can also be set/overridden at runtime from the
in-app Settings screen — that value takes priority over the build-time default.

For CI, set the `JARVIS_API_KEY` and `JARVIS_API_BASE_URL` repository secrets (see
`.github/workflows/android-build.yml`); they are never committed to the repo.

## Permissions

| Permission | Why it's needed | When requested |
|---|---|---|
| `RECORD_AUDIO` | Wake word + voice commands | On first mic use |
| `POST_NOTIFICATIONS` | Reminders, foreground service status | On first launch (Android 13+) |
| `FOREGROUND_SERVICE_MICROPHONE` | Keeps wake-word listening alive | Automatic with mic grant |
| `QUERY_ALL_PACKAGES` | Dynamic app launching | Install-time |
| Notification Listener access | Optional: react to incoming notifications | User enables manually in system settings, then toggles on in-app |
| Accessibility Service | Optional: advanced automation (open a specific chat) | User enables manually in system settings |

JARVIS never activates the notification listener or accessibility service without both the
system-level grant **and** an explicit in-app toggle in Settings.

## Testing

- Unit tests: `./gradlew testDebugUnitTest` (command parsing, time parsing)
- Instrumented tests: `./gradlew connectedDebugAndroidTest` (Room DAO behavior)

## CI

`.github/workflows/android-build.yml` runs unit tests and builds a debug APK on every push/PR,
uploading it as a workflow artifact.

## License

See `LICENSE` (placeholder — choose a license before publishing).
