package com.jarvis.assistant.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class NaturalLanguageTimeParserTest {

    @Test
    fun `tomorrow morning resolves to next day at 8am`() {
        val now = Calendar.getInstance().apply {
            set(2026, Calendar.JANUARY, 15, 14, 0, 0)
        }
        val result = Calendar.getInstance().apply {
            timeInMillis = NaturalLanguageTimeParser.parse("tomorrow morning", now)
        }
        assertEquals(16, result.get(Calendar.DAY_OF_MONTH))
        assertEquals(8, result.get(Calendar.HOUR_OF_DAY))
    }

    @Test
    fun `in two hours adds two hours to now`() {
        val now = Calendar.getInstance().apply {
            set(2026, Calendar.JANUARY, 15, 10, 0, 0)
        }
        val resultMillis = NaturalLanguageTimeParser.parse("in two hours", now)
        val expected = (now.clone() as Calendar).apply { add(Calendar.HOUR_OF_DAY, 2) }.timeInMillis
        assertTrue(Math.abs(resultMillis - expected) < 60_000)
    }

    @Test
    fun `unrecognized phrase falls back to one hour from now`() {
        val now = Calendar.getInstance()
        val resultMillis = NaturalLanguageTimeParser.parse("someday eventually", now)
        val expectedMin = now.timeInMillis + (55 * 60 * 1000)
        val expectedMax = now.timeInMillis + (65 * 60 * 1000)
        assertTrue(resultMillis in expectedMin..expectedMax)
    }

    @Test
    fun `russian tomorrow phrase is recognized`() {
        val now = Calendar.getInstance().apply {
            set(2026, Calendar.JANUARY, 15, 10, 0, 0)
        }
        val result = Calendar.getInstance().apply {
            timeInMillis = NaturalLanguageTimeParser.parse("завтра", now)
        }
        assertEquals(16, result.get(Calendar.DAY_OF_MONTH))
    }
}
