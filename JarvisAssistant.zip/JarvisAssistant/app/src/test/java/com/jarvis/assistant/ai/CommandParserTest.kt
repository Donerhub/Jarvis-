package com.jarvis.assistant.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {

    @Test
    fun `various open app phrasings resolve to the same app name`() {
        val phrasings = listOf(
            "Open YouTube.",
            "Launch YouTube.",
            "Go to YouTube.",
            "I want YouTube.",
            "Can you open YouTube?"
        )
        for (phrase in phrasings) {
            val intent = CommandParser.parse(phrase)
            assertTrue("Expected OpenApp for \"$phrase\" but got $intent", intent is JarvisIntent.OpenApp)
            assertEquals("YouTube", (intent as JarvisIntent.OpenApp).spokenAppName)
        }
    }

    @Test
    fun `reminder phrase splits text and time correctly`() {
        val intent = CommandParser.parse("remind me to call mom tomorrow morning")
        assertTrue(intent is JarvisIntent.CreateReminder)
        val reminder = intent as JarvisIntent.CreateReminder
        assertEquals("call mom", reminder.text)
        assertEquals("tomorrow morning", reminder.timePhrase)
    }

    @Test
    fun `russian open app phrase is recognized`() {
        val intent = CommandParser.parse("Открой Telegram")
        assertTrue(intent is JarvisIntent.OpenApp)
        assertEquals("Telegram", (intent as JarvisIntent.OpenApp).spokenAppName)
    }

    @Test
    fun `unrecognized text falls back to conversation`() {
        val intent = CommandParser.parse("What's the weather like today?")
        assertTrue(intent is JarvisIntent.Conversation)
    }

    @Test
    fun `flashlight command is recognized regardless of casing`() {
        val intent = CommandParser.parse("Turn on the FLASHLIGHT")
        assertTrue(intent is JarvisIntent.ToggleFlashlight)
    }
}
