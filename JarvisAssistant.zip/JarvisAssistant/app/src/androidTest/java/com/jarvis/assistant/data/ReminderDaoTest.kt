package com.jarvis.assistant.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.jarvis.assistant.data.local.db.JarvisDatabase
import com.jarvis.assistant.data.local.entity.ReminderEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ReminderDaoTest {

    private lateinit var database: JarvisDatabase

    @Before
    fun setUp() {
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            JarvisDatabase::class.java
        ).allowMainThreadQueries().build()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun insertAndReadActiveReminder() = runTest {
        val dao = database.reminderDao()
        val id = dao.insert(
            ReminderEntity(text = "Call mom", triggerAtEpochMillis = System.currentTimeMillis() + 3600_000)
        )

        val active = dao.observeActive().first()
        assertEquals(1, active.size)
        assertEquals("Call mom", active.first().text)
        assertTrue(id > 0)
    }

    @Test
    fun markCompletedRemovesFromActiveList() = runTest {
        val dao = database.reminderDao()
        val id = dao.insert(
            ReminderEntity(text = "Buy milk", triggerAtEpochMillis = System.currentTimeMillis() + 1000)
        )

        dao.markCompleted(id)

        val active = dao.observeActive().first()
        assertTrue(active.isEmpty())
    }
}
