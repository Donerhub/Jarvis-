package com.jarvis.assistant.data.repository

import com.jarvis.assistant.data.local.dao.ConversationDao
import com.jarvis.assistant.data.local.entity.ConversationMessageEntity
import com.jarvis.assistant.data.remote.ChatCompletionRequest
import com.jarvis.assistant.data.remote.ChatMessageDto
import com.jarvis.assistant.data.remote.OpenAiApi
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.MessageRole
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConversationRepository @Inject constructor(
    private val api: OpenAiApi,
    private val dao: ConversationDao,
    private val settingsRepository: SettingsRepository
) {
    fun observeMessages(): Flow<List<ChatMessage>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    /**
     * Sends [userText] to the AI with recent conversation history as context,
     * persists both the user message and the assistant reply, and returns the reply text.
     */
    suspend fun sendMessage(userText: String, systemPrompt: String, model: String = "gpt-4o-mini"): Result<String> {
        return try {
            dao.insert(
                ConversationMessageEntity(role = "user", content = userText)
            )

            val history = dao.getRecent(MAX_CONTEXT_MESSAGES).reversed()
            val messages = buildList {
                add(ChatMessageDto(role = "system", content = systemPrompt))
                history.forEach { add(ChatMessageDto(role = it.role, content = it.content)) }
            }

            val response = api.createChatCompletion(
                ChatCompletionRequest(model = model, messages = messages)
            )
            val replyText = response.choices.firstOrNull()?.message?.content
                ?: "I'm sorry, I couldn't generate a response."

            dao.insert(
                ConversationMessageEntity(role = "assistant", content = replyText)
            )

            Result.success(replyText)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    suspend fun clearHistory() = dao.clearAll()

    private fun ConversationMessageEntity.toDomain() = ChatMessage(
        id = id,
        role = when (role) {
            "user" -> MessageRole.USER
            "assistant" -> MessageRole.ASSISTANT
            else -> MessageRole.SYSTEM
        },
        content = content,
        timestampEpochMillis = timestampEpochMillis
    )

    companion object {
        private const val MAX_CONTEXT_MESSAGES = 20
    }
}
