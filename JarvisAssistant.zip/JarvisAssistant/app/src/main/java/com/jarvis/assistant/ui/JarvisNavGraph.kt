package com.jarvis.assistant.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.assistant.ui.screens.home.HomeScreen
import com.jarvis.assistant.ui.screens.settings.SettingsScreen

object JarvisRoutes {
    const val HOME = "home"
    const val SETTINGS = "settings"
}

@Composable
fun JarvisNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = JarvisRoutes.HOME) {
        composable(JarvisRoutes.HOME) {
            HomeScreen(onOpenSettings = { navController.navigate(JarvisRoutes.SETTINGS) })
        }
        composable(JarvisRoutes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
