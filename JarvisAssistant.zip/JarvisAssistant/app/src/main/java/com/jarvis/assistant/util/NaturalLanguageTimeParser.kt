package com.jarvis.assistant.util

import java.util.Calendar
import java.util.Locale

/**
 * Lightweight natural-language time parser for reminder phrases like
 * "tomorrow morning", "tonight", "next Friday", "in two hours", "at 5 PM".
 * Supports English, Russian, and Kazakh keywords. Falls back to "in 1 hour"
 * if nothing recognizable is found, so a reminder is never silently dropped.
 */
object NaturalLanguageTimeParser {

    private val numberWords = mapOf(
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6,
        "один" to 1, "два" to 2, "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6,
        "бір" to 1, "екі" to 2, "үш" to 3, "төрт" to 4, "бес" to 5, "алты" to 6
    )

    fun parse(phrase: String, now: Calendar = Calendar.getInstance()): Long {
        val text = phrase.lowercase(Locale.getDefault())
        val cal = now.clone() as Calendar

        // "at HH[:MM] [am/pm]"
        Regex("""(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""").find(text)?.let { match ->
            val hasTimeKeyword = text.contains("at ") || text.contains("в ") || text.contains("сағат")
            if (hasTimeKeyword) {
                var hour = match.groupValues[1].toInt()
                val minute = match.groupValues[2].toIntOrNull() ?: 0
                val meridiem = match.groupValues[3]
                if (meridiem == "pm" && hour < 12) hour += 12
                if (meridiem == "am" && hour == 12) hour = 0
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                cal.set(Calendar.SECOND, 0)
                if (cal.timeInMillis <= now.timeInMillis) cal.add(Calendar.DAY_OF_YEAR, 1)
                return cal.timeInMillis
            }
        }

        // "in N hours/minutes"
        Regex("""in (\w+) (hour|minute|min|час|минут|сағат|минут)""").find(text)?.let { match ->
            val amount = match.groupValues[1].toIntOrNull() ?: numberWords[match.groupValues[1]] ?: 1
            val unit = match.groupValues[2]
            when {
                unit.startsWith("hour") || unit.startsWith("час") || unit.startsWith("сағат") ->
                    cal.add(Calendar.HOUR_OF_DAY, amount)
                else -> cal.add(Calendar.MINUTE, amount)
            }
            return cal.timeInMillis
        }

        when {
            text.contains("tomorrow morning") || text.contains("завтра утром") || text.contains("ертең таңертең") -> {
                cal.add(Calendar.DAY_OF_YEAR, 1)
                cal.set(Calendar.HOUR_OF_DAY, 8); cal.set(Calendar.MINUTE, 0)
                return cal.timeInMillis
            }
            text.contains("tomorrow") || text.contains("завтра") || text.contains("ертең") -> {
                cal.add(Calendar.DAY_OF_YEAR, 1)
                cal.set(Calendar.HOUR_OF_DAY, 9); cal.set(Calendar.MINUTE, 0)
                return cal.timeInMillis
            }
            text.contains("tonight") || text.contains("сегодня вечером") || text.contains("бүгін кешке") -> {
                cal.set(Calendar.HOUR_OF_DAY, 20); cal.set(Calendar.MINUTE, 0)
                if (cal.timeInMillis <= now.timeInMillis) cal.add(Calendar.DAY_OF_YEAR, 1)
                return cal.timeInMillis
            }
            text.contains("next friday") || text.contains("следующую пятницу") || text.contains("келесі жұма") -> {
                return nextWeekday(cal, Calendar.FRIDAY)
            }
        }

        // Fallback: 1 hour from now, so we never fail to create a reminder.
        cal.add(Calendar.HOUR_OF_DAY, 1)
        return cal.timeInMillis
    }

    private fun nextWeekday(cal: Calendar, targetDay: Int): Long {
        do {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        } while (cal.get(Calendar.DAY_OF_WEEK) != targetDay)
        cal.set(Calendar.HOUR_OF_DAY, 9)
        cal.set(Calendar.MINUTE, 0)
        return cal.timeInMillis
    }
}
