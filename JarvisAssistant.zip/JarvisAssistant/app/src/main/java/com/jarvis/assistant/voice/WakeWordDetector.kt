package com.jarvis.assistant.voice

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WakeWordDetector @Inject constructor(
    private val context: Context
) {
    private val _isWakeWordDetected = MutableStateFlow(false)
    val isWakeWordDetected: StateFlow<Boolean> = _isWakeWordDetected.asStateFlow()

    private val targetWakeWord = "jarvis"

    fun processAudioFrame(text: String): Boolean {
        if (text.lowercase().contains(targetWakeWord)) {
            _isWakeWordDetected.value = true
            return true
        }
        return false
    }

    fun resetDetection() {
        _isWakeWordDetected.value = false
    }
}