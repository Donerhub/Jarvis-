package com.jarvis.assistant.ai

import com.jarvis.assistant.domain.model.CommandType
import com.jarvis.assistant.domain.model.ParsedCommand
import com.jarvis.assistant.util.AppLauncher
import com.jarvis.assistant.util.ReminderScheduler
import com.jarvis.assistant.data.repository.ReminderRepository
import com.jarvis.assistant.domain.model.Reminder
import com.jarvis.assistant.util.SystemStatusProvider
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IntentRouter @Inject constructor(
    private val appLauncher: AppLauncher,
    private val reminderScheduler: ReminderScheduler,
    private val reminderRepository: ReminderRepository,
    private val systemStatusProvider: SystemStatusProvider,
    private val aiEngine: AiEngine,
    private val memoryManager: MemoryManager
) {

    suspend fun routeAndExecute(command: ParsedCommand): String {
        return when (command.type) {
            CommandType.OPEN_APP -> {
                val launched = appLauncher.launchAppByName(command.payload)
                if (launched) "Opening ${command.payload}" else "Application ${command.payload} not found."
            }
            CommandType.CREATE_REMINDER -> {
                val reminder = Reminder(
                    id = 0,
                    title = "Reminder",
                    message = command.payload,
                    triggerAtEpochMilli = System.currentTimeMillis() + 60000,
                    isCompleted = false
                )
                val id = reminderRepository.insertReminder(reminder)
                reminderScheduler.schedule(reminder.copy(id = id))
                "Reminder set for: ${command.payload}"
            }
            CommandType.SYSTEM_STATUS -> {
                systemStatusProvider.getSystemStatusSummary()
            }
            CommandType.REMEMBER_FACT -> {
                memoryManager.saveFact(command.payload)
                "I will remember that: ${command.payload}"
            }
            CommandType.CHAT_QUERY -> {
                aiEngine.generateResponse(command.payload)
            }
        }
    }
}