package com.jarvis.assistant.ai

import com.jarvis.assistant.data.remote.OpenAiApi
import com.jarvis.assistant.data.remote.OpenAiRequest
import com.jarvis.assistant.data.remote.OpenAiMessage
import com.jarvis.assistant.data.repository.SettingsRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AiEngine @Inject constructor(
    private val openAiApi: OpenAiApi,
    private val settingsRepository: SettingsRepository,
    private val memoryManager: MemoryManager
) {

    suspend fun generateResponse(userPrompt: String): String {
        val apiKey = settingsRepository.getApiKey().first()
        if (apiKey.isBlank()) {
            return "API Key is missing. Please set your OpenAI API key in Settings."
        }

        val relevantFacts = memoryManager.getRelevantMemoryContext(userPrompt)
        val systemPrompt = buildString {
            append("You are Jarvis, a highly intelligent voice assistant. ")
            if (relevantFacts.isNotEmpty()) {
                append("Here is context remembered about the user: ")
                append(relevantFacts.joinToString("; "))
                append(". ")
            }
            append("Be concise, precise, and helpful.")
        }

        val request = OpenAiRequest(
            model = "gpt-4o-mini",
            messages = listOf(
                OpenAiMessage(role = "system", content = systemPrompt),
                OpenAiMessage(role = "user", content = userPrompt)
            )
        )

        return try {
            val response = openAiApi.getChatCompletion("Bearer $apiKey", request)
            response.choices.firstOrNull()?.message?.content ?: "I didn't receive a response."
        } catch (e: Exception) {
            "An error occurred: ${e.localizedMessage ?: "Unknown error"}"
        }
    }
}