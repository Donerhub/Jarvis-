package com.jarvis.assistant.ai

import com.jarvis.assistant.data.local.dao.MemoryDao
import com.jarvis.assistant.data.local.entity.MemoryFactEntity
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryManager @Inject constructor(
    private val memoryDao: MemoryDao
) {

    suspend fun saveFact(fact: String) {
        if (fact.isNotBlank()) {
            memoryDao.insertFact(
                MemoryFactEntity(
                    fact = fact.trim(),
                    createdAtEpochMilli = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun getRelevantMemoryContext(query: String): List<String> {
        val allFacts = memoryDao.getAllFacts().first()
        val queryKeywords = query.lowercase().split(" ")
        
        return allFacts.filter { factEntity ->
            queryKeywords.any { keyword -> keyword.length > 3 && factEntity.fact.lowercase().contains(keyword) }
        }.map { it.fact }.ifEmpty {
            allFacts.takeLast(5).map { it.fact }
        }
    }

    suspend fun clearAllMemory() {
        memoryDao.deleteAllFacts()
    }
}