package com.jarvis.assistant.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.jarvis.assistant.data.local.entity.ConversationMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ConversationMessageEntity): Long

    @Query("SELECT * FROM conversation_messages ORDER BY timestampEpochMillis ASC")
    fun observeAll(): Flow<List<ConversationMessageEntity>>

    /** Most recent N messages, used to build AI context without unbounded growth. */
    @Query("SELECT * FROM conversation_messages ORDER BY timestampEpochMillis DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<ConversationMessageEntity>

    @Query("DELETE FROM conversation_messages")
    suspend fun clearAll()
}
