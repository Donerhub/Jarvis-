package com.jarvis.assistant.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.data.repository.AssistantLanguage
import com.jarvis.assistant.data.repository.JarvisSettings
import com.jarvis.assistant.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<JarvisSettings> = settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), JarvisSettings())

    fun setLanguage(language: AssistantLanguage) {
        viewModelScope.launch { settingsRepository.setLanguage(language) }
    }

    fun setApiKey(key: String) {
        viewModelScope.launch { settingsRepository.setApiKey(key) }
    }

    fun setOfflineOnly(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setOfflineModeOnly(enabled) }
    }

    fun setHabitReminders(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setHabitRemindersEnabled(enabled) }
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setWakeWordEnabled(enabled) }
    }
}
