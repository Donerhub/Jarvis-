package com.jarvis.assistant.data.remote

import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

data class ChatMessageDto(
    val role: String,
    val content: String
)

data class ChatCompletionRequest(
    val model: String,
    val messages: List<ChatMessageDto>,
    val temperature: Double = 0.7,
    val max_tokens: Int = 800
)

data class ChatCompletionChoice(
    val index: Int,
    val message: ChatMessageDto,
    val finish_reason: String?
)

data class ChatCompletionResponse(
    val id: String?,
    val choices: List<ChatCompletionChoice>
)

interface OpenAiApi {
    @Headers("Content-Type: application/json")
    @POST("chat/completions")
    suspend fun createChatCompletion(@Body request: ChatCompletionRequest): ChatCompletionResponse
}
