package com.jarvis.assistant.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsDataStore by preferencesDataStore(name = "jarvis_settings")

enum class AssistantLanguage(val code: String, val displayName: String) {
    KAZAKH("kk", "Қазақша"),
    RUSSIAN("ru", "Русский"),
    ENGLISH("en", "English"),
    AUTO("auto", "Automatic")
}

data class JarvisSettings(
    val language: AssistantLanguage = AssistantLanguage.AUTO,
    val apiKey: String = "",
    val apiBaseUrl: String = "",
    val offlineModeOnly: Boolean = false,
    val habitRemindersEnabled: Boolean = true,
    val wakeWordEnabled: Boolean = true,
    val notificationAccessEnabled: Boolean = false
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val API_KEY = stringPreferencesKey("api_key")
        val API_BASE_URL = stringPreferencesKey("api_base_url")
        val OFFLINE_ONLY = booleanPreferencesKey("offline_only")
        val HABIT_REMINDERS = booleanPreferencesKey("habit_reminders")
        val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val NOTIFICATION_ACCESS = booleanPreferencesKey("notification_access")
    }

    val settingsFlow: Flow<JarvisSettings> = context.settingsDataStore.data.map { prefs ->
        JarvisSettings(
            language = AssistantLanguage.entries.find { it.code == prefs[Keys.LANGUAGE] }
                ?: AssistantLanguage.AUTO,
            apiKey = prefs[Keys.API_KEY] ?: "",
            apiBaseUrl = prefs[Keys.API_BASE_URL] ?: "",
            offlineModeOnly = prefs[Keys.OFFLINE_ONLY] ?: false,
            habitRemindersEnabled = prefs[Keys.HABIT_REMINDERS] ?: true,
            wakeWordEnabled = prefs[Keys.WAKE_WORD_ENABLED] ?: true,
            notificationAccessEnabled = prefs[Keys.NOTIFICATION_ACCESS] ?: false
        )
    }

    suspend fun setLanguage(language: AssistantLanguage) {
        context.settingsDataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setApiKey(key: String) {
        context.settingsDataStore.edit { it[Keys.API_KEY] = key }
    }

    suspend fun setOfflineModeOnly(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.OFFLINE_ONLY] = enabled }
    }

    suspend fun setHabitRemindersEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.HABIT_REMINDERS] = enabled }
    }

    suspend fun setWakeWordEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.WAKE_WORD_ENABLED] = enabled }
    }

    suspend fun setNotificationAccessEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.NOTIFICATION_ACCESS] = enabled }
    }

    fun currentApiKeyBlocking(): String = runBlocking {
        settingsFlow.first().apiKey
    }
}

/**
 * Small indirection so NetworkModule's OkHttp interceptor (a singleton created once)
 * can still read the *current* user-set API key on every request without recreating
 * the OkHttpClient whenever settings change.
 */
@Singleton
class ApiKeyProvider @Inject constructor(
    private val settingsRepository: SettingsRepository
) {
    fun currentKey(): String = settingsRepository.currentApiKeyBlocking()
}
