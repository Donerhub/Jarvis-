package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.domain.model.AssistantState
import com.jarvis.assistant.ui.theme.JarvisNeonBlue
import com.jarvis.assistant.ui.theme.JarvisNeonCyan
import com.jarvis.assistant.ui.theme.JarvisNeonPurple
import com.jarvis.assistant.ui.theme.JarvisSurfaceGlass

/**
 * The central animated "AI core" shown on the home dashboard.
 * Reacts visually to [state]: idle pulse, faster/brighter when listening/thinking/speaking.
 */
@Composable
fun AiCore(
    state: AssistantState,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp
) {
    val transition = rememberInfiniteTransition(label = "ai-core")

    val speedMillis = when (state) {
        AssistantState.LISTENING -> 900
        AssistantState.THINKING -> 650
        AssistantState.SPEAKING -> 500
        AssistantState.ERROR -> 1400
        AssistantState.IDLE -> 2400
    }

    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(speedMillis, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(speedMillis * 6, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val coreColor = when (state) {
        AssistantState.ERROR -> Color(0xFFFF5C5C)
        AssistantState.SPEAKING -> JarvisNeonCyan
        AssistantState.THINKING -> JarvisNeonPurple
        else -> JarvisNeonBlue
    }

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(size)) {
            val ringRadius = (this.size.minDimension / 2) * pulse
            val center = Offset(this.size.width / 2, this.size.height / 2)

            // Outer glow rings
            for (i in 1..3) {
                drawCircle(
                    color = coreColor.copy(alpha = 0.10f / i),
                    radius = ringRadius * (0.7f + i * 0.12f),
                    center = center
                )
            }

            // Rotating dashed ring
            rotate(rotation, pivot = center) {
                drawCircle(
                    color = coreColor.copy(alpha = 0.55f),
                    radius = ringRadius * 0.75f,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            // Solid inner core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(coreColor, coreColor.copy(alpha = 0.15f)),
                    center = center,
                    radius = ringRadius * 0.45f
                ),
                radius = ringRadius * 0.45f,
                center = center
            )
        }
    }
}

/** Reusable glassmorphism-style card used throughout the dashboard and settings. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(JarvisSurfaceGlass)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(JarvisNeonBlue.copy(alpha = 0.35f), Color.Transparent)
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .padding(16.dp)
    ) {
        content()
    }
}
