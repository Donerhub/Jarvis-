package com.jarvis.assistant.util

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max

data class InstalledAppInfo(
    val label: String,
    val packageName: String
)

sealed class LaunchResult {
    data class Success(val app: InstalledAppInfo) : LaunchResult()
    data class MultipleMatches(val candidates: List<InstalledAppInfo>) : LaunchResult()
    object NotFound : LaunchResult()
}

/**
 * Resolves spoken app names ("open YouTube", "launch CapCut") to installed applications
 * using PackageManager at runtime — no hardcoded package list.
 */
@Singleton
class AppLauncher @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val packageManager: PackageManager = context.packageManager

    fun listLaunchableApps(): List<InstalledAppInfo> {
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        return packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { resolveInfo ->
                val appInfo: ApplicationInfo = resolveInfo.activityInfo?.applicationInfo ?: return@mapNotNull null
                InstalledAppInfo(
                    label = resolveInfo.loadLabel(packageManager).toString(),
                    packageName = appInfo.packageName
                )
            }
            .distinctBy { it.packageName }
    }

    /** Finds the best match(es) for [spokenName] among installed apps and resolves the result. */
    fun resolve(spokenName: String): LaunchResult {
        val query = spokenName.trim().lowercase()
        if (query.isEmpty()) return LaunchResult.NotFound

        val apps = listLaunchableApps()
        val scored = apps.map { it to similarity(query, it.label.lowercase()) }
            .filter { it.second > 0.35 }
            .sortedByDescending { it.second }

        if (scored.isEmpty()) return LaunchResult.NotFound

        val best = scored.first().second
        val topMatches = scored.filter { it.second >= best - 0.08 }.map { it.first }

        return when {
            topMatches.size == 1 -> LaunchResult.Success(topMatches.first())
            topMatches.size > 1 -> LaunchResult.MultipleMatches(topMatches.take(5))
            else -> LaunchResult.NotFound
        }
    }

    fun launch(app: InstalledAppInfo): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    /** Simple normalized similarity: exact/contains gets a high score, else Levenshtein-based ratio. */
    private fun similarity(query: String, candidate: String): Double {
        if (candidate == query) return 1.0
        if (candidate.contains(query) || query.contains(candidate)) return 0.85
        val distance = levenshtein(query, candidate)
        val maxLen = max(query.length, candidate.length)
        if (maxLen == 0) return 0.0
        return 1.0 - (distance.toDouble() / maxLen)
    }

    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[a.length][b.length]
    }
}
