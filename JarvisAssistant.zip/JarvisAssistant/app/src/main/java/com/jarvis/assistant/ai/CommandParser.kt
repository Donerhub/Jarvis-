package com.jarvis.assistant.ai

sealed class JarvisIntent {
    data class OpenApp(val spokenAppName: String) : JarvisIntent()
    data class CreateReminder(val text: String, val timePhrase: String) : JarvisIntent()
    data class OpenChatShortcut(val label: String) : JarvisIntent()
    object ToggleFlashlight : JarvisIntent()
    data class Conversation(val text: String) : JarvisIntent()
}

/**
 * Recognizes intent from free-form speech without relying on a fixed phrase list —
 * matches on flexible keyword patterns in English, Russian, and Kazakh so that
 * "open YouTube", "launch YouTube", "go to YouTube", and "I want YouTube" all resolve
 * to the same OpenApp intent.
 */
object CommandParser {

    private val openAppTriggers = listOf(
        "open ", "launch ", "go to ", "start ", "can you open ", "i want ",
        "открой ", "запусти ", "включи ", "открыть ",
        "аш ", "іске қос ", "жүктеп бер "
    )

    private val reminderTriggers = listOf(
        "remind me to ", "remind me ", "set a reminder to ", "set a reminder for ",
        "напомни мне ", "напомни ", "поставь напоминание ",
        "еске сал ", "маған еске сал "
    )

    private val chatShortcutTriggers = listOf(
        "open chat with ", "open ", // "open Ali's chat" also matches openApp; disambiguated by "chat"
        "открой чат с ", "чат с ",
        "чатын аш "
    )

    private val flashlightTriggers = listOf(
        "flashlight", "фонарик", "фонарь", "шам", "фонарик"
    )

    fun parse(rawText: String): JarvisIntent {
        val text = rawText.trim()
        val lower = text.lowercase()

        if (flashlightTriggers.any { lower.contains(it) }) {
            return JarvisIntent.ToggleFlashlight
        }

        if (lower.contains("chat") || lower.contains("чат")) {
            chatShortcutTriggers.firstOrNull { lower.startsWith(it) }?.let { trigger ->
                val label = text.substring(trigger.length).removeSuffix("'s chat").trim()
                if (label.isNotBlank()) return JarvisIntent.OpenChatShortcut(label)
            }
        }

        reminderTriggers.firstOrNull { lower.startsWith(it) }?.let { trigger ->
            val remainder = text.substring(trigger.length).trim()
            val (reminderText, timePhrase) = splitReminderAndTime(remainder)
            return JarvisIntent.CreateReminder(reminderText, timePhrase)
        }

        openAppTriggers.firstOrNull { lower.startsWith(it) }?.let { trigger ->
            val appName = text.substring(trigger.length)
                .removeSuffix("?")
                .trim()
            if (appName.isNotBlank()) return JarvisIntent.OpenApp(appName)
        }

        return JarvisIntent.Conversation(text)
    }

    /**
     * Splits a reminder phrase like "call mom tomorrow morning" into
     * ("call mom", "tomorrow morning") by looking for known time-phrase keywords.
     */
    private fun splitReminderAndTime(text: String): Pair<String, String> {
        val timeKeywords = listOf(
            "tomorrow morning", "tomorrow", "tonight", "next friday", "in ", "at ",
            "завтра утром", "завтра", "сегодня вечером", "следующую пятницу", "через ", "в ",
            "ертең таңертең", "ертең", "бүгін кешке", "келесі жұма", "сағат"
        )
        for (keyword in timeKeywords) {
            val index = text.lowercase().indexOf(keyword)
            if (index > 0) {
                val reminderText = text.substring(0, index).trim()
                val timePhrase = text.substring(index).trim()
                if (reminderText.isNotBlank()) return reminderText to timePhrase
            }
        }
        // No explicit time phrase found — caller will fall back to "in 1 hour".
        return text to ""
    }
}
