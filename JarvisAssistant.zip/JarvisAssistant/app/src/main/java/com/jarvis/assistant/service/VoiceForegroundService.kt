package com.jarvis.assistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.data.repository.SettingsRepository
import com.jarvis.assistant.voice.SpeechEvent
import com.jarvis.assistant.voice.SpeechRecognitionManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * A foreground service that repeatedly performs short wake-word listening windows.
 * It intentionally does NOT keep the microphone open continuously — it listens in short
 * bursts and backs off, which is far more battery-friendly than an always-open stream
 * while still giving a responsive "Jarvis" wake experience.
 */
@AndroidEntryPoint
class VoiceForegroundService : Service() {

    @Inject lateinit var speechRecognitionManager: SpeechRecognitionManager
    @Inject lateinit var settingsRepository: SettingsRepository

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var wakeWordJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startWakeWordLoop()
        return START_STICKY
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        wakeWordJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startWakeWordLoop() {
        if (wakeWordJob?.isActive == true) return
        wakeWordJob = serviceScope.launch {
            while (true) {
                val settings = settingsRepository.settingsFlow.first()
                if (!settings.wakeWordEnabled) {
                    delay(BACKOFF_WHEN_DISABLED_MS)
                    continue
                }

                var heardWakeWord = false
                speechRecognitionManager.listen().collectSafely { event ->
                    if (event is SpeechEvent.FinalResult &&
                        event.text.contains(WAKE_WORD, ignoreCase = true)
                    ) {
                        heardWakeWord = true
                    }
                }

                if (heardWakeWord) {
                    onWakeWordDetected()
                }

                delay(LISTEN_WINDOW_COOLDOWN_MS)
            }
        }
    }

    private suspend fun onWakeWordDetected() {
        // The Activity/ViewModel layer owns the actual conversation turn; here we just
        // surface a broadcast/notification so the UI can react (e.g. bring app to front,
        // play the activation sound/animation). Kept intentionally decoupled from UI code.
        val activationIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            putExtra(EXTRA_WAKE_WORD_TRIGGERED, true)
        }
        startActivity(activationIntent)
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, JarvisApplication.CHANNEL_VOICE_SERVICE)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Listening for \"Jarvis\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 42
        private const val WAKE_WORD = "jarvis"
        private const val LISTEN_WINDOW_COOLDOWN_MS = 1500L
        private const val BACKOFF_WHEN_DISABLED_MS = 5000L
        const val EXTRA_WAKE_WORD_TRIGGERED = "extra_wake_word_triggered"
    }
}

/** Small helper to collect a Flow while swallowing cancellation/errors so the loop never crashes the service. */
private suspend inline fun <T> kotlinx.coroutines.flow.Flow<T>.collectSafely(
    crossinline action: suspend (T) -> Unit
) {
    try {
        collect { action(it) }
    } catch (t: Throwable) {
        // Recognition errors (timeout, no match) are expected during idle wake-word windows.
    }
}
