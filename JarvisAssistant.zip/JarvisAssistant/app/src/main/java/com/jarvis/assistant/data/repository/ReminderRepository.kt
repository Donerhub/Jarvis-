package com.jarvis.assistant.data.repository

import com.jarvis.assistant.data.local.dao.ReminderDao
import com.jarvis.assistant.data.local.entity.ReminderEntity
import com.jarvis.assistant.domain.model.Reminder
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReminderRepository @Inject constructor(
    private val dao: ReminderDao
) {
    fun observeActiveReminders(): Flow<List<Reminder>> =
        dao.observeActive().map { list -> list.map { it.toDomain() } }

    fun observeAllReminders(): Flow<List<Reminder>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun createReminder(text: String, triggerAtEpochMillis: Long, languageCode: String): Long =
        dao.insert(
            ReminderEntity(
                text = text,
                triggerAtEpochMillis = triggerAtEpochMillis,
                languageCode = languageCode
            )
        )

    suspend fun markCompleted(id: Long) = dao.markCompleted(id)

    suspend fun delete(reminder: Reminder) =
        dao.delete(
            ReminderEntity(
                id = reminder.id,
                text = reminder.text,
                triggerAtEpochMillis = reminder.triggerAtEpochMillis,
                isCompleted = reminder.isCompleted
            )
        )

    private fun ReminderEntity.toDomain() = Reminder(
        id = id,
        text = text,
        triggerAtEpochMillis = triggerAtEpochMillis,
        isCompleted = isCompleted
    )
}
