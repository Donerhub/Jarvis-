package com.jarvis.assistant.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.jarvis.assistant.data.local.dao.ConversationDao
import com.jarvis.assistant.data.local.dao.MemoryDao
import com.jarvis.assistant.data.local.dao.ReminderDao
import com.jarvis.assistant.data.local.entity.ChatShortcutEntity
import com.jarvis.assistant.data.local.entity.ConversationMessageEntity
import com.jarvis.assistant.data.local.entity.HabitLogEntity
import com.jarvis.assistant.data.local.entity.MemoryFactEntity
import com.jarvis.assistant.data.local.entity.ReminderEntity

@Database(
    entities = [
        ReminderEntity::class,
        ConversationMessageEntity::class,
        MemoryFactEntity::class,
        HabitLogEntity::class,
        ChatShortcutEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun reminderDao(): ReminderDao
    abstract fun conversationDao(): ConversationDao
    abstract fun memoryDao(): MemoryDao

    companion object {
        const val DATABASE_NAME = "jarvis_database"
    }
}
