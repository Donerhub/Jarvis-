package com.jarvis.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.assistant.domain.model.SpeechTone
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Wraps Android's TextToSpeech engine and varies pitch/rate per [SpeechTone]
 * to give the assistant an emotion-aware speaking style.
 */
@Singleton
class TextToSpeechManager @Inject constructor(
    @ApplicationContext context: Context
) {
    private var tts: TextToSpeech? = null
    private var isReady = false

    init {
        tts = TextToSpeech(context) { status ->
            isReady = status == TextToSpeech.SUCCESS
        }
    }

    fun setLanguage(locale: Locale) {
        tts?.language = locale
    }

    suspend fun speak(text: String, tone: SpeechTone = SpeechTone.CALM) {
        val engine = tts ?: return
        if (!isReady) return

        val (pitch, rate) = toneToPitchRate(tone)
        engine.setPitch(pitch)
        engine.setSpeechRate(rate)

        val utteranceId = UUID.randomUUID().toString()
        suspendCoroutine<Unit> { continuation ->
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    continuation.resume(Unit)
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    continuation.resume(Unit)
                }
            })
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
    }

    private fun toneToPitchRate(tone: SpeechTone): Pair<Float, Float> = when (tone) {
        SpeechTone.CALM -> 1.0f to 1.0f
        SpeechTone.POLITE -> 1.0f to 0.95f
        SpeechTone.SERIOUS -> 0.9f to 0.9f
        SpeechTone.EXCITED -> 1.15f to 1.1f
        SpeechTone.REASSURING -> 0.95f to 0.9f
        SpeechTone.FRIENDLY -> 1.05f to 1.0f
        SpeechTone.URGENT -> 1.1f to 1.2f
    }
}
