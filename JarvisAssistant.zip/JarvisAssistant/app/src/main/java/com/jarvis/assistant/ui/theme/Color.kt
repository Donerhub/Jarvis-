package com.jarvis.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisBackground = Color(0xFF000814)
val JarvisSurface = Color(0xFF06121F)
val JarvisSurfaceGlass = Color(0x2606D4FF)
val JarvisNeonBlue = Color(0xFF4FD8FF)
val JarvisNeonCyan = Color(0xFF00E5FF)
val JarvisNeonPurple = Color(0xFF7B61FF)
val JarvisTextPrimary = Color(0xFFE7F6FF)
val JarvisTextSecondary = Color(0xFF8FB4C9)
val JarvisWarning = Color(0xFFFFB020)
val JarvisError = Color(0xFFFF5C5C)
val JarvisSuccess = Color(0xFF4CE0A6)
