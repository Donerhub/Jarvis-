package com.jarvis.assistant.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.ai.CommandParser
import com.jarvis.assistant.ai.JarvisIntent
import com.jarvis.assistant.data.repository.ConversationRepository
import com.jarvis.assistant.data.repository.ReminderRepository
import com.jarvis.assistant.data.repository.SettingsRepository
import com.jarvis.assistant.domain.model.AssistantState
import com.jarvis.assistant.domain.model.Reminder
import com.jarvis.assistant.util.AppLauncher
import com.jarvis.assistant.util.LaunchResult
import com.jarvis.assistant.util.ReminderScheduler
import com.jarvis.assistant.util.SystemStatus
import com.jarvis.assistant.util.SystemStatusProvider
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val assistantState: AssistantState = AssistantState.IDLE,
    val greeting: String = "",
    val systemStatus: SystemStatus? = null,
    val upcomingReminders: List<Reminder> = emptyList(),
    val languageLabel: String = "Automatic",
    val lastAssistantReply: String = ""
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val reminderRepository: ReminderRepository,
    private val conversationRepository: ConversationRepository,
    private val settingsRepository: SettingsRepository,
    private val systemStatusProvider: SystemStatusProvider,
    private val appLauncher: AppLauncher,
    private val reminderScheduler: ReminderScheduler
) : ViewModel() {

    private val _assistantState = MutableStateFlow(AssistantState.IDLE)
    private val _systemStatus = MutableStateFlow<SystemStatus?>(null)
    private val _lastReply = MutableStateFlow("")

    val uiState: StateFlow<HomeUiState> = combine(
        _assistantState,
        _systemStatus,
        reminderRepository.observeActiveReminders(),
        settingsRepository.settingsFlow,
        _lastReply
    ) { assistantState, status, reminders, settings, lastReply ->
        HomeUiState(
            assistantState = assistantState,
            greeting = greetingForCurrentTime(),
            systemStatus = status,
            upcomingReminders = reminders.take(3),
            languageLabel = settings.language.displayName,
            lastAssistantReply = lastReply
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())

    init {
        viewModelScope.launch {
            while (true) {
                _systemStatus.value = systemStatusProvider.currentStatus()
                delay(5000)
            }
        }
    }

    fun onMicPressed() {
        viewModelScope.launch {
            _assistantState.value = AssistantState.LISTENING
        }
    }

    fun onUserUtterance(text: String) {
        viewModelScope.launch {
            _assistantState.value = AssistantState.THINKING

            val reply = when (val intent = CommandParser.parse(text)) {
                is JarvisIntent.OpenApp -> handleOpenApp(intent.spokenAppName)
                is JarvisIntent.CreateReminder -> handleCreateReminder(intent)
                is JarvisIntent.OpenChatShortcut -> "I don't have a saved shortcut for \"${intent.label}\" yet."
                JarvisIntent.ToggleFlashlight -> "Flashlight toggled."
                is JarvisIntent.Conversation -> {
                    val systemPrompt = buildSystemPrompt()
                    conversationRepository.sendMessage(intent.text, systemPrompt)
                        .getOrElse { "Sorry, I ran into a problem: ${it.message}" }
                }
            }

            _assistantState.value = AssistantState.SPEAKING
            _lastReply.value = reply
            delay(2500)
            _assistantState.value = AssistantState.IDLE
        }
    }

    private fun handleOpenApp(spokenName: String): String {
        return when (val result = appLauncher.resolve(spokenName)) {
            is LaunchResult.Success -> {
                appLauncher.launch(result.app)
                "Opening ${result.app.label}."
            }
            is LaunchResult.MultipleMatches -> {
                val names = result.candidates.joinToString(", ") { it.label }
                "I found a few matches: $names. Which one did you mean?"
            }
            LaunchResult.NotFound -> "I couldn't find an app called \"$spokenName\" installed."
        }
    }

    private suspend fun handleCreateReminder(intent: JarvisIntent.CreateReminder): String {
        val language = settingsRepository.settingsFlow.first().language.code
        reminderScheduler.scheduleFromNaturalLanguage(
            text = intent.text,
            naturalLanguagePhrase = intent.timePhrase.ifBlank { "in 1 hour" },
            languageCode = language
        )
        return "Got it — I'll remind you to ${intent.text}."
    }

    private fun buildSystemPrompt(): String =
        "You are JARVIS, a calm, professional, and friendly personal AI assistant living inside " +
            "an Android app. Reply concisely and naturally in the same language the user used " +
            "(Kazakh, Russian, or English). Never mention you are a language model."

    private fun greetingForCurrentTime(): String {
        val hour = java.time.LocalTime.now().hour
        return when {
            hour < 12 -> "Good morning. How can I help you?"
            hour < 18 -> "Hello. I'm listening."
            else -> "Good evening. What do you need?"
        }
    }
}
