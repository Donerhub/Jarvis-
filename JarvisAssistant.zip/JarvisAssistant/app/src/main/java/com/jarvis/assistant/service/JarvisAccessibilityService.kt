package com.jarvis.assistant.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Optional accessibility service. Android will not bind this unless the user has
 * explicitly granted accessibility access in system settings — JARVIS never enables
 * it automatically. Used to support advanced automation (e.g. tapping into a specific
 * chat inside a third-party app) that plain Intents cannot reach.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally minimal: this service only inspects window content on demand
        // when an in-progress automation command needs it (e.g. "open Ali's chat" after
        // the target app has been launched). No passive logging of screen content occurs.
    }

    override fun onInterrupt() {
        // No-op: nothing to clean up between interruptions.
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo?.apply {
            notificationTimeout = 100
        }
    }

    /**
     * Performs a global action (back, home, recents) on behalf of a voice command,
     * e.g. "go back" or "go home".
     */
    fun performGlobalCommand(action: Int): Boolean = performGlobalAction(action)
}
