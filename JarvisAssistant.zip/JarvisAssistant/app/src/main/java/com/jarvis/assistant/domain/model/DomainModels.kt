package com.jarvis.assistant.domain.model

enum class MessageRole { USER, ASSISTANT, SYSTEM }

data class ChatMessage(
    val id: Long = 0,
    val role: MessageRole,
    val content: String,
    val timestampEpochMillis: Long = System.currentTimeMillis()
)

data class Reminder(
    val id: Long = 0,
    val text: String,
    val triggerAtEpochMillis: Long,
    val isCompleted: Boolean = false
)

enum class AssistantState { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

enum class SpeechTone { CALM, POLITE, SERIOUS, EXCITED, REASSURING, FRIENDLY, URGENT }
