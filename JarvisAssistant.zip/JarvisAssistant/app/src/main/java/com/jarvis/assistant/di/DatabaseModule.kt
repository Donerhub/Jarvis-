package com.jarvis.assistant.di

import android.content.Context
import androidx.room.Room
import com.jarvis.assistant.data.local.dao.ConversationDao
import com.jarvis.assistant.data.local.dao.MemoryDao
import com.jarvis.assistant.data.local.dao.ReminderDao
import com.jarvis.assistant.data.local.db.JarvisDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): JarvisDatabase =
        Room.databaseBuilder(context, JarvisDatabase::class.java, JarvisDatabase.DATABASE_NAME)
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideReminderDao(db: JarvisDatabase): ReminderDao = db.reminderDao()

    @Provides
    fun provideConversationDao(db: JarvisDatabase): ConversationDao = db.conversationDao()

    @Provides
    fun provideMemoryDao(db: JarvisDatabase): MemoryDao = db.memoryDao()
}
