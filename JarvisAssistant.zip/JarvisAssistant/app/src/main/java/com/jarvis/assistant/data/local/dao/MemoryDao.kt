package com.jarvis.assistant.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.jarvis.assistant.data.local.entity.ChatShortcutEntity
import com.jarvis.assistant.data.local.entity.HabitLogEntity
import com.jarvis.assistant.data.local.entity.MemoryFactEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFact(fact: MemoryFactEntity)

    @Query("SELECT * FROM memory_facts WHERE category = :category")
    fun observeFactsByCategory(category: String): Flow<List<MemoryFactEntity>>

    @Query("SELECT * FROM memory_facts")
    fun observeAllFacts(): Flow<List<MemoryFactEntity>>

    @Query("SELECT value FROM memory_facts WHERE category = :category AND `key` = :key LIMIT 1")
    suspend fun getFact(category: String, key: String): String?

    @Query("DELETE FROM memory_facts WHERE category = :category AND `key` = :key")
    suspend fun deleteFact(category: String, key: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun logHabit(habit: HabitLogEntity): Long

    @Query("SELECT * FROM habit_logs WHERE packageName = :packageName ORDER BY openedAtEpochMillis DESC LIMIT :limit")
    suspend fun getRecentHabits(packageName: String, limit: Int): List<HabitLogEntity>

    @Query("SELECT COUNT(*) FROM habit_logs WHERE packageName = :packageName AND openedAtEpochMillis >= :sinceEpochMillis")
    suspend fun countOpensSince(packageName: String, sinceEpochMillis: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShortcut(shortcut: ChatShortcutEntity): Long

    @Delete
    suspend fun deleteShortcut(shortcut: ChatShortcutEntity)

    @Query("SELECT * FROM chat_shortcuts ORDER BY label ASC")
    fun observeShortcuts(): Flow<List<ChatShortcutEntity>>

    @Query("SELECT * FROM chat_shortcuts WHERE label LIKE '%' || :query || '%' LIMIT 5")
    suspend fun findShortcuts(query: String): List<ChatShortcutEntity>
}
