package com.jarvis.assistant.util

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.jarvis.assistant.data.repository.ReminderRepository
import com.jarvis.assistant.service.ReminderWorker
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReminderScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val reminderRepository: ReminderRepository
) {
    /**
     * Parses [naturalLanguagePhrase] for a time, persists the reminder, and schedules
     * a WorkManager job to fire at that time. Returns the created reminder id.
     */
    suspend fun scheduleFromNaturalLanguage(
        text: String,
        naturalLanguagePhrase: String,
        languageCode: String
    ): Long {
        val triggerAtMillis = NaturalLanguageTimeParser.parse(naturalLanguagePhrase)
        val reminderId = reminderRepository.createReminder(text, triggerAtMillis, languageCode)

        val delay = (triggerAtMillis - System.currentTimeMillis()).coerceAtLeast(0)
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(
                Data.Builder()
                    .putLong(ReminderWorker.KEY_REMINDER_ID, reminderId)
                    .putString(ReminderWorker.KEY_REMINDER_TEXT, text)
                    .build()
            )
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "reminder_$reminderId",
            ExistingWorkPolicy.REPLACE,
            request
        )

        return reminderId
    }
}
