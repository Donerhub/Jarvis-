package com.jarvis.assistant.util

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.StatFs
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class SystemStatus(
    val batteryPercent: Int,
    val isCharging: Boolean,
    val isOnline: Boolean,
    val networkType: String,
    val availableStorageGb: Float,
    val totalStorageGb: Float,
    val availableRamMb: Long,
    val totalRamMb: Long
)

@Singleton
class SystemStatusProvider @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun currentStatus(): SystemStatus {
        val batteryStatus = context.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val capabilities = network?.let { connectivityManager.getNetworkCapabilities(it) }
        val isOnline = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val networkType = when {
            capabilities == null -> "Offline"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            else -> "Other"
        }

        val stat = StatFs(context.filesDir.path)
        val availableGb = (stat.availableBytes / (1024f * 1024f * 1024f))
        val totalGb = (stat.totalBytes / (1024f * 1024f * 1024f))

        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val availableRamMb = memInfo.availMem / (1024 * 1024)
        val totalRamMb = memInfo.totalMem / (1024 * 1024)

        return SystemStatus(
            batteryPercent = batteryPct,
            isCharging = charging,
            isOnline = isOnline,
            networkType = networkType,
            availableStorageGb = availableGb,
            totalStorageGb = totalGb,
            availableRamMb = availableRamMb,
            totalRamMb = totalRamMb
        )
    }
}
