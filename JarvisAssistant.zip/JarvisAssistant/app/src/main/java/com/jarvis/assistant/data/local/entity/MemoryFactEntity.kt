package com.jarvis.assistant.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Generic persisted memory fact, e.g.:
 *  category="profile", key="name", value="Ali"
 *  category="schedule", key="work_start", value="09:00"
 *  category="favorite_app", key="music", value="com.spotify.music"
 */
@Entity(tableName = "memory_facts", primaryKeys = ["category", "key"])
data class MemoryFactEntity(
    val category: String,
    val key: String,
    val value: String,
    val updatedAtEpochMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "habit_logs")
data class HabitLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appLabel: String,
    val openedAtEpochMillis: Long = System.currentTimeMillis(),
    val sessionDurationMillis: Long = 0
)

@Entity(tableName = "chat_shortcuts")
data class ChatShortcutEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val packageName: String,
    val shortcutId: String?,
    val deepLinkUri: String?
)
