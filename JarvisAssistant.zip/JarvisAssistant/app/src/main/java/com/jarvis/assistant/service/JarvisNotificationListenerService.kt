package com.jarvis.assistant.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.jarvis.assistant.data.repository.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Reads notification metadata ONLY when the user has explicitly granted
 * notification-listener access in system settings AND enabled it in-app.
 * This service never reads notification content unless both conditions hold.
 */
@AndroidEntryPoint
class JarvisNotificationListenerService : NotificationListenerService() {

    @Inject lateinit var settingsRepository: SettingsRepository

    private val scope = CoroutineScope(Dispatchers.Default + Job())

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        scope.launch {
            val settings = settingsRepository.settingsFlow.first()
            if (!settings.notificationAccessEnabled) return@launch

            val title = sbn.notification.extras.getString("android.title").orEmpty()
            val text = sbn.notification.extras.getString("android.text").orEmpty()
            // Intentionally not logged/persisted here — downstream consumers (e.g. a habit
            // tracker or "you have a new message from X" voice announcement) would subscribe
            // via a repository call; kept minimal to respect user privacy by default.
            onRelevantNotification(sbn.packageName, title, text)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // No-op: JARVIS does not need to react to notification dismissal.
    }

    private fun onRelevantNotification(packageName: String, title: String, text: String) {
        // Hook point for future features (e.g. "You got a message from $title").
        // Deliberately does not persist notification bodies to the database.
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

