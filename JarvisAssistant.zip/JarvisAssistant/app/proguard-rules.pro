# Keep Room entities and DAOs
-keep class com.jarvis.assistant.data.local.entity.** { *; }
-keep class com.jarvis.assistant.data.local.dao.** { *; }

# Keep Retrofit/Gson models
-keep class com.jarvis.assistant.data.remote.** { *; }
-keepattributes Signature
-keepattributes *Annotation*

# Hilt
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.HiltAndroidApp

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# General Android
-keepattributes SourceFile,LineNumberTable
-dontwarn org.jetbrains.annotations.**
